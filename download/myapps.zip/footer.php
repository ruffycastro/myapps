<section id="footer">
				<div class="container">
					<header class="major">
						<h2>Get in touch</h2>
					</header>
					<form method="post" action="#">
						<div class="row uniform">
							<div class="6u 12u$(xsmall)"><input type="text" name="name" id="name" placeholder="Name" /></div>
							<div class="6u$ 12u$(xsmall)"><input type="email" name="email" id="email" placeholder="Email" /></div>
							<div class="12u$"><textarea name="message" id="message" placeholder="Message" rows="4"></textarea></div>
							<div class="12u$">
								<ul class="actions">
									<li><input type="submit" value="Send Message" class="special" /></li>
								</ul>
							</div>
						</div>
					</form>
				</div>
				<footer>
					<?php if ( is_active_sidebar( 'footersocial' ) ) : ?>
					<?php dynamic_sidebar( 'footersocial' ); ?>
					<?php endif; ?>
					<ul class="copyright">
						<li>&copy; <a href="http://ogiecastro.com">Ogie Castro</a></li><li>Design: <a href="#">HTML5</a></li><li>Demo Images: <a href="http://unsplash.com" target="_blank">Unsplash</a></li>
					</ul>
				</footer>
			</section>

		<!-- Scripts -->
			<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/js/jquery.min.js"></script>
			<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/js/jquery.scrollex.min.js"></script>
			<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/js/jquery.scrolly.min.js"></script>
			<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/js/skel.min.js"></script>
			<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/js/main.js"></script>

	</body>
	<?php wp_footer();?>
</html>