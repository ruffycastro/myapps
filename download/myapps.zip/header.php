<!DOCTYPE HTML>
<html>
	<head>
		<title><?php bloginfo( 'name' ); ?></title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/style.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<?php wp_head();?>
	</head>
	<body>

		<!-- Header -->
			<section id="header">
				<header class="major">
					<h1><?php bloginfo( 'name' ); ?></h1>
					<p><?php bloginfo('description'); ?> by <a href="http://ogiecastro.com">ogiecastro</a></p>
				</header>
				<div class="container">
					<ul class="actions">
						<li><a href="#one" class="button special scrolly">Begin</a></li>
					</ul>
				</div>
			</section>
