<?php
function who_iam() {
    register_sidebar( array(
        'name'      	=> ('Who I Am'),
        'id'        	=> 'whoiam',
        'before_widget' => '<section id="one" class="main special">',
        'after_widget'  => '</section>',
        'before_title'  => '',
        'after_title'   => '',
    ) );
}
add_action( 'widgets_init', 'who_iam' );
function stuff_i_do() {
    register_sidebar( array(
        'name'      	=> ('Stuff I Do'),
        'id'        	=> 'stuffido',
        'before_widget' => '<section id="two" class="main special">',
        'after_widget'  => '</section>',
        'before_title'  => '',
        'after_title'   => '',
    ) );
}
add_action( 'widgets_init', 'stuff_i_do' );
function one_more_thing() {
    register_sidebar( array(
        'name'      	=> ('One More thing'),
        'id'        	=> 'onemorething',
        'before_widget' => '<section id="three" class="main special">',
        'after_widget'  => '</section>',
        'before_title'  => '',
        'after_title'   => '',
    ) );
}
add_action( 'widgets_init', 'one_more_thing' );

function footer_icons() {
    register_sidebar( array(
        'name'      	=> ('Footer Social'),
        'id'        	=> 'footersocial',
        'before_widget' => '<ul class="icons">',
        'after_widget'  => '</ul>',
        'before_title'  => '',
        'after_title'   => '',
    ) );
}
add_action( 'widgets_init', 'footer_icons' );
?>