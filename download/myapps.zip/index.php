<?php get_header();?>
		<!-- One -->
			<?php if ( is_active_sidebar( 'whoiam' ) ) : ?>
			<?php dynamic_sidebar( 'whoiam' ); ?>
			<?php endif; ?>
		<!-- Two -->
			<?php if ( is_active_sidebar( 'stuffido' ) ) : ?>
			<?php dynamic_sidebar( 'stuffido' ); ?>
			<?php endif; ?>
		<!-- Three -->
			<?php if ( is_active_sidebar( 'onemorething' ) ) : ?>
			<?php dynamic_sidebar( 'onemorething' ); ?>
			<?php endif; ?>
<?php get_footer();?>